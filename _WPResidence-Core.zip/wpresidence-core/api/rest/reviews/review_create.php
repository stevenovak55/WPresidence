<?php 
/**
 * Post a review for a property, agent, agency, or developer.
 * 
 * Submits a review for a given entity and handles validation and response.
 *
 * @param WP_REST_Request $request The REST API request.
 * @return WP_REST_Response|WP_Error Success response or error details.
 */
function wpresidence_post_review(WP_REST_Request $request) {
    // Get current user
    $current_user = wp_get_current_user();
    $userID = $current_user->ID;
    
    // Check if user is logged in
    if ($userID === 0) {
        return new WP_Error(
            'rest_unauthorized',
            __('You must be logged in to post a review.'),
            ['status' => 401]
        );
    }
    
    // Get user info
    $user_login = $current_user->user_login;
    $user_email = $current_user->user_email;
    
    // Parse request parameters
    $params = $request->get_params();
    
    // Validation
    if (empty($params['listing_id']) || !is_numeric($params['listing_id'])) {
        return new WP_Error(
            'rest_invalid_param',
            __('Invalid listing ID.'),
            ['status' => 400]
        );
    }
    
    $listing_id = intval($params['listing_id']);
    
    // Verify post type
    $post_type = get_post_type($listing_id);
    $allowed_post_types = ['estate_property', 'estate_agent', 'estate_agency', 'estate_developer'];
    
    if (!in_array($post_type, $allowed_post_types)) {
        return new WP_Error(
            'rest_invalid_post_type',
            __('Reviews can only be posted for properties, agents, agencies, or developers.'),
            ['status' => 400]
        );
    }
    
    // Validate stars rating
    if (empty($params['stars']) || !is_numeric($params['stars']) || $params['stars'] < 1 || $params['stars'] > 5) {
        return new WP_Error(
            'rest_invalid_param',
            __('Star rating must be between 1 and 5.'),
            ['status' => 400]
        );
    }
    
    $stars = intval($params['stars']);
    
    // Validate content
    if (empty($params['content'])) {
        return new WP_Error(
            'rest_invalid_param',
            __('Review content is required.'),
            ['status' => 400]
        );
    }
    
    $allowed_html = array();
    $content = wp_kses($params['content'], $allowed_html);
    $title = !empty($params['title']) ? wp_kses($params['title'], $allowed_html) : '';
    
    // Set approval status
    $comment_approved = 0;
    if (wpresidence_get_option('wp_estate_admin_approves_reviews', '') == 'no') {
        $comment_approved = 1;
    }
    
    // Get current time
    $time = current_time('mysql');
    
    // Prepare comment data
    $data = array(
        'comment_post_ID' => $listing_id,
        'comment_author' => $user_login,
        'comment_author_email' => $user_email,
        'comment_author_url' => '',
        'comment_content' => $content,
        'comment_type' => 'comment',
        'comment_parent' => 0,
        'user_id' => $userID,
        'comment_author_IP' => $_SERVER['REMOTE_ADDR'],
        'comment_agent' => $_SERVER['HTTP_USER_AGENT'],
        'comment_date' => $time,
        'comment_approved' => $comment_approved,
    );
    
    // Insert comment
    $comment_id = wp_insert_comment($data);
    
    // Check if comment was inserted successfully
    if (!$comment_id || is_wp_error($comment_id)) {
        return new WP_Error(
            'rest_comment_failed',
            __('Failed to post review.'),
            ['status' => 500]
        );
    }
    
    // Add comment meta
    add_comment_meta($comment_id, 'review_title', $title);
    add_comment_meta($comment_id, 'review_stars', $stars);
    
    // Send email notification
    $entity_name = get_the_title($listing_id);
    $arguments = array(
        'agent_name' => $entity_name,
        'user_post' => $user_login
    );
    
    wpestate_select_email_type(get_option('admin_email'), 'agent_review', $arguments);
    
    // Return success response
    $response_data = array(
        'status' => 'success',
        'comment_id' => $comment_id,
        'message' => __('Review posted successfully.'),
        'approved' => ($comment_approved == 1)
    );
    
    return rest_ensure_response($response_data);
}