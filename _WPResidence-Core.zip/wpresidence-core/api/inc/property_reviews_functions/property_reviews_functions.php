<?php

/**
 * WordPress AJAX handler for submitting property reviews
 * 
 * This function processes review submissions on property listings.
 * It validates the user is logged in, processes the review data,
 * and inserts the review as a comment with additional metadata for stars and title.
 * 
 * @package WP Estate
 * @subpackage Reviews
 * @return void
 */
add_action('wp_ajax_wpestate_post_review', 'wpestate_post_review');

if (!function_exists('wpestate_post_review')):
    function wpestate_post_review() {
        // Verify nonce for security
        check_ajax_referer('wpestate_review_nonce', 'security');
        
        // Get current user information
        $current_user = wp_get_current_user();
        $userID = $current_user->ID;
        $allowed_html = array();
        
        // Validate user is logged in
        if (!is_user_logged_in()) {
            exit('ko');
        }
        
        // Additional validation that user ID is not 0
        if ($userID === 0) {
            exit('out pls');
        }
        
        // Get user details for the comment
        $userID = $current_user->ID;
        $user_login = $current_user->user_login;
        $user_email = $current_user->user_email;
        
        // Get review data from POST request
        $listing_id = intval($_POST['listing_id']);
        $stars = intval($_POST['stars']);
        $content = wp_kses($_POST['content'], $allowed_html);
        $title = wp_kses($_POST['title'], $allowed_html);
        
        // Set up timestamp for the comment
        $time = time();
        $time = current_time('mysql');
        
        // Determine if review requires approval
        $comment_approved = 0; // Default: requires approval
        if (wpresidence_get_option('wp_estate_admin_approves_reviews', '') == 'no') {
            $comment_approved = 1; // Auto-approve if setting is 'no'
        }
        
        // Prepare comment data array
        $data = array(
            'comment_post_ID' => $listing_id,
            'comment_author' => $user_login,
            'comment_author_email' => $user_email,
            'comment_author_url' => '',
            'comment_content' => $content,
            'comment_type' => 'comment',
            'comment_parent' => 0,
            'user_id' => $userID,
            'comment_author_IP' => '127.0.0.1',
            'comment_agent' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10 (.NET CLR 3.5.30729)',
            'comment_date' => $time,
            'comment_approved' => $comment_approved,
        );
        
        // Insert the comment into the database
        $comment_id = wp_insert_comment($data);
        
        // Add review-specific metadata to the comment
        add_comment_meta($comment_id, 'review_title', $title);
        add_comment_meta($comment_id, 'review_stars', $stars);
        
        // Prepare notification email arguments
        $arguments = array(
            'agent_name' => get_the_title($listing_id),
            'user_post' => $user_login
        );
        
        // Send email notification about the new review
        wpestate_select_email_type(get_option('admin_email'), 'agent_review', $arguments);
        
        // End AJAX request
        die();
    }
endif;



/**
 * WordPress AJAX handler for editing property reviews
 * 
 * This function processes edit requests for existing property reviews.
 * It validates the user is logged in and is the original author of the review,
 * updates the review content and metadata, and notifies admins of the edit.
 * 
 * @package WP Estate
 * @subpackage Reviews
 * @return void
 */
add_action('wp_ajax_wpestate_edit_review', 'wpestate_edit_review');

if (!function_exists('wpestate_edit_review')):
    function wpestate_edit_review() {
        // Verify nonce for security
        check_ajax_referer('wpestate_review_nonce', 'security');
        
        // Get current user information
        $current_user = wp_get_current_user();
        $userID = $current_user->ID;
        $user_login = $current_user->user_login;
        $allowed_html = array();
        
        // Validate user is logged in
        if (!is_user_logged_in()) {
            exit('ko');
        }
        
        // Additional validation that user ID is not 0
        if ($userID === 0) {
            exit('out pls');
        }
        
        // Get the comment ID from POST data
        $comment_ID = intval($_POST['coment']);
        $coment = get_comment($comment_ID);
        
        // Debug output - prints current user ID and comment author ID
        print intval($userID) . '/ ' . intval($coment->user_id);
        
        // Validate the current user is the author of the comment
        if ($coment->user_id != $userID) {
            exit('no');
        }
        
        // Get updated review data from POST request
        $listing_id = intval($_POST['listing_id']);
        $stars = intval($_POST['stars']);
        $content = wp_kses($_POST['content'], $allowed_html);
        $title = wp_kses($_POST['title'], $allowed_html);
        
        // Update review metadata
        update_comment_meta($comment_ID, 'review_title', $title);
        update_comment_meta($comment_ID, 'review_stars', $stars);
        update_comment_meta($comment_ID, 'comment_content', $content);
        
        // Prepare comment data array for update
        $commentarr = array();
        $commentarr['comment_ID'] = $comment_ID;
        $commentarr['comment_content'] = $content;
        
        // Determine if edited review requires approval
        $comment_approved = 0; // Default: requires approval
        if (wpresidence_get_option('wp_estate_admin_approves_reviews', '') == 'no') {
            $comment_approved = 1; // Auto-approve if setting is 'no'
        }
        $commentarr['comment_approved'] = $comment_approved;
        
        // Update the comment in the database
        wp_update_comment($commentarr);
        
        // Prepare notification email arguments
        $arguments = array(
            'agent_name' => get_the_title($listing_id),
            'user_post' => $user_login
        );
        
        // Send email notification about the edited review
        wpestate_select_email_type(get_option('admin_email'), 'agent_review', $arguments);
        
        // End AJAX request
        die();
    }
endif;