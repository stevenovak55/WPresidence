<?php 

/**
 * WpResidence Updates function
 * This file handles functions used in data updates betwen versions
 */

   
/**
 * Hook the migration to plugin update
 */
function wpresidence_check_version_and_migrate() {
    $current_version = get_option('wpresidence_version');

    if ($current_version && version_compare($current_version, '5.1.0', '<')) {
        wpresidence_migrate_user_roles_to_510();
    }
    // Update version after migration
    update_option('wpresidence_version', '5.1.0');
}

add_action('admin_init', 'wpresidence_migrate_user_roles_to_510',9999);



 /**
 * One-time migration for user roles based on user_type meta
 * Run during plugin update to version 3.13
 * 
 * @return void
 */
function wpresidence_migrate_user_roles_to_510() {


    // Verify admin privileges
    if (!current_user_can('manage_options')) {
     
        return;
    }
    // Check if migration already ran
    if (get_option('wpresidence_migrate_user_roles_to_510')) {
     
        return;
    }
     // Create roles if needed
    if (!get_role(WPRESIDENCE_ROLE_AGENT) || !get_role(WPRESIDENCE_ROLE_AGENCY)  || !get_role(WPRESIDENCE_ROLE_DEVELOPER)  ) {
        wpresidence_create_custom_roles();
    }
   
    // Get all users with 'user_type' meta
    $users = get_users(array(
        'meta_key' => 'user_estate_role',
        'compare' => 'EXISTS',
        'fields' => array('ID'),
        'role__not_in' => array('administrator', 'editor', 'author', 'contributor'),
    ));

    foreach ($users as $user) {
      
        $user_type = intval(get_user_meta($user->ID, 'user_estate_role', true));
        $user_obj = new WP_User($user->ID);
        $user_roles = [
            1 => 'subscriber',
            2 => defined('WPRESIDENCE_ROLE_AGENT') ? WPRESIDENCE_ROLE_AGENT : 'wpresidence_agent_role',
            3 => defined('WPRESIDENCE_ROLE_AGENCY') ? WPRESIDENCE_ROLE_AGENCY : 'wpresidence_agency_role',
            4 => defined('WPRESIDENCE_ROLE_DEVELOPER') ? WPRESIDENCE_ROLE_DEVELOPER : 'wpresidence_developer_role'
        ];


        // Determine role based on user_type
        $new_role = isset($user_roles[$user_type]) ? $user_roles[$user_type] : 'subscriber';
          
        // Store existing roles except administrator
        $existing_roles = array_diff($user_obj->roles, array('administrator', 'editor', 'author', 'contributor'));

        // Add new role without removing existing ones
        $user_obj->add_role($new_role);


        /*
          // Log migration
          error_log(sprintf(
            'WpResidence Migration: User %d assigned role %s while preserving roles: %s',
            $user->ID,
            $new_role,
            implode(', ', $existing_roles)
        ));
        */
    }
    
    // Mark migration as complete
    update_option('wpresidence_migrate_user_roles_to_510', true, false);
}