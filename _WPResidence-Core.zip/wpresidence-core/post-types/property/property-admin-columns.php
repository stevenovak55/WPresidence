<?php
/**
 * Property Admin Columns Management
 *
 * This file handles the customization of WordPress admin columns for properties,
 * property cities, and property areas. It defines column layouts, populates column
 * content, and manages sorting functionality for the property listing interface
 * in the WordPress admin panel.
 *
 * @package WPResidence
 * @subpackage Core
 * @since 1.0
 */

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///  Manage property lists
///////////////////////////////////////////////////////////////////////////////////////////////////////////
add_filter('manage_edit-estate_property_columns', 'wpestate_my_columns');

if (!function_exists('wpestate_my_columns')):
    /**
     * Defines custom columns for property listings in admin
     * 
     * Customizes the columns shown in the properties list table including:
     * ID, thumbnail, location info, property details, pricing, and featured status
     *
     * @param array $columns The default WordPress columns
     * @return array Modified array of columns
     */
    function wpestate_my_columns($columns) {
        $slice = array_slice($columns, 2, 2);
        unset($columns['comments']);
        unset($slice['comments']);
        $splice = array_splice($columns, 2);
        $columns['estate_ID'] = esc_html__('ID', 'wpresidence-core');
        $columns['estate_thumb'] = esc_html__('Image', 'wpresidence-core');
        $columns['estate_city'] = esc_html__('City', 'wpresidence-core');
        $columns['estate_action'] = esc_html__('Action', 'wpresidence-core');
        $columns['estate_category'] = esc_html__('Category', 'wpresidence-core');
        $columns['estate_autor'] = esc_html__('User', 'wpresidence-core');
        $columns['estate_status'] = esc_html__('Status', 'wpresidence-core');
        $columns['estate_price'] = esc_html__('Price', 'wpresidence-core');
        $columns['estate_featured'] = esc_html__('Featured', 'wpresidence-core');
        return array_merge($columns, array_reverse($slice));
    }
endif;

add_action('manage_posts_custom_column', 'wpestate_populate_columns');
if (!function_exists('wpestate_populate_columns')):
    /**
     * Populates content for custom columns in property listings
     * 
     * Handles the display of data in each custom column including contact information,
     * property details, taxonomies, pricing, and featured status.
     *
     * @param string $column The name of the column being populated
     * @return void
     */
    function wpestate_populate_columns($column) {
        global $post;
        $the_id = $post->ID;

        if ('estate_ID' == $column) {
            echo $the_id;
        } else if ('estate_agent_email' == $column) {
            $agent_email = get_post_meta($the_id, 'agent_email', true);
            echo $agent_email;
        } else if ('estate_agency_email' == $column) {
            $agent_email = get_post_meta($the_id, 'agency_email', true);
            echo $agent_email;
        } else if ('estate_agency_email' == $column) {
            $agent_email = get_post_meta($the_id, 'agency_email', true);
            echo $agent_email;
        } else if ('estate_developer_email' == $column) {
            $agent_email = get_post_meta($the_id, 'developer_email', true);
            echo $agent_email;
        } else if ('estate_agency_phone' == $column) {
            $agent_phone = get_post_meta($the_id, 'agency_phone', true);
            $agent_mobile = get_post_meta($the_id, 'agency_mobile', true);
            echo $agent_phone . ' / ' . $agent_mobile;
        } else if ('estate_developer_phone' == $column) {
            $agent_phone = get_post_meta($the_id, 'developer_phone', true);
            $agent_mobile = get_post_meta($the_id, 'developer_mobile', true);
            echo $agent_phone . ' / ' . $agent_mobile;
        } else if ('estate_agent_phone' == $column) {
            $agent_phone = get_post_meta($the_id, 'agent_phone', true);
            $agent_mobile = get_post_meta($the_id, 'agent_mobile', true);
            echo $agent_phone . ' / ' . $agent_mobile;
        } else if ('estate_agent_city' == $column) {
            $estate_action = get_the_term_list($the_id, 'property_city_agent', '', ', ', '');
            echo ($estate_action);
        } else if ('estate_agent_action' == $column) {
            $estate_action = get_the_term_list($the_id, 'property_action_category_agent', '', ', ', '');
            echo ($estate_action);
        } else if ('estate_agent_category' == $column) {
            $estate_category = get_the_term_list($the_id, 'property_category_agent', '', ', ', '');
            echo ($estate_category);
        } else if ('estate_agency_city' == $column) {
            $estate_action = get_the_term_list($the_id, 'city_agency', '', ', ', '');
            echo ($estate_action);
        } else if ('estate_agency_action' == $column) {
            $estate_action = get_the_term_list($the_id, 'action_category_agency', '', ', ', '');
            echo ($estate_action);
        } else if ('estate_agency_category' == $column) {
            $estate_category = get_the_term_list($the_id, 'category_agency', '', ', ', '');
            echo ($estate_category);
        } else if ('estate_developer_city' == $column) {
            $estate_action = get_the_term_list($the_id, 'property_city_developer', '', ', ', '');
            echo ($estate_action);
        } else if ('estate_developer_action' == $column) {
            $estate_action = get_the_term_list($the_id, 'property_action_developer', '', ', ', '');
            echo ($estate_action);
        } else if ('estate_developer_category' == $column) {
            $estate_category = get_the_term_list($the_id, 'property_category_developer', '', ', ', '');
            echo ($estate_category);
        } else if ('estate_status' == $column) {
            $estate_status = get_post_status($the_id);
            if ($estate_status == 'publish') {
                echo esc_html__('published', 'wpresidence-core');
            } else {
                echo esc_html($estate_status);
            }

            $pay_status = get_post_meta($the_id, 'pay_status', true);
            if ($pay_status != '') {
                echo " | ";
                if ($pay_status == 'paid') {
                    esc_html_e('PAID', 'wpresidence-core');
                } else {
                    esc_html_e('Not Paid', 'wpresidence-core');
                }
            }
        } else if ('estate_autor' == $column) {
            $temp_id = $post->ID;
            $user_id = wpsestate_get_author($the_id);
            $estate_autor = get_the_author_meta('display_name', $user_id);
            echo '<a href="' . get_edit_user_link($user_id) . '" >' . $estate_autor . '</a>';

            $post->ID = $temp_id = $the_id;
        } else if ('estate_thumb' == $column || 'estate_agent_thumb' == $column || 'estate_agency_thumb' == $column || 'estate_developer_thumb' == $column) {
            $thumb_id = get_post_thumbnail_id($the_id);
            $post_thumbnail_url = wp_get_attachment_image_src($thumb_id, 'slider_thumb');
            if (isset($post_thumbnail_url[0])) {
                echo '<img src="' . $post_thumbnail_url[0] . '" style="width:100%;height:auto;">';
            }
        } else if ('estate_city' == $column) {
            $estate_city = get_the_term_list($the_id, 'property_city', '', ', ', '');
            echo ($estate_city);
        } else if ('estate_action' == $column) {
            $estate_action = get_the_term_list($the_id, 'property_action_category', '', ', ', '');
            echo ($estate_action);
        } elseif ('estate_category' == $column) {
            $estate_category = get_the_term_list($the_id, 'property_category', '', ', ', '');
            echo ($estate_category);
        } else if ('estate_price' == $column) {
            $wpestate_currency = esc_html(wpresidence_get_option('wp_estate_currency_symbol', ''));
            $where_currency = esc_html(wpresidence_get_option('wp_estate_where_currency_symbol', ''));
            $price = floatval(get_post_meta($the_id, 'property_price', true));
            $second_price = floatval(get_post_meta($the_id, 'property_second_price', true));
            if ($price != 0) {
                $th_separator = stripslashes(wpresidence_get_option('wp_estate_prices_th_separator', ''));
                $price = wpestate_format_number_price($price, $th_separator);
                if ($where_currency == 'before') {
                    $price = $wpestate_currency . ' ' . $price;
                } else {
                    $price = $price . ' ' . $wpestate_currency;
                }
            } else {
                $price = '';
            }

            if ($second_price != 0) {
                $th_separator = stripslashes(wpresidence_get_option('wp_estate_prices_th_separator', ''));
                $second_price = wpestate_format_number_price($second_price, $th_separator);

                if ($where_currency == 'before') {
                    $second_price = $wpestate_currency . ' ' . $second_price;
                } else {
                    $second_price = $second_price . ' ' . $where_currency;
                }
            } else {
                $second_price = '';
            }

            echo '<div class="wpestate_admin_price_wrapper">' . get_post_meta($the_id, 'property_label_before', true) . ' ' . $price . ' ' . get_post_meta($the_id, 'property_label', true) . '</div>';

            echo '<div class="wpestate_admin_second_price_wrapper">' . get_post_meta($the_id, 'property_label_before_second_price', true) . ' ' . $second_price . ' ' . get_post_meta($the_id, 'property_second_price_label', true) . '</div>';
        } else if ('estate_featured' == $column) {
            $estate_featured = get_post_meta($the_id, 'prop_featured', true);
            if ($estate_featured == 1) {
                $estate_featured = esc_html__('Yes', 'wpresidence-core');
            } else {
                $estate_featured = esc_html__('No', 'wpresidence-core');
            }
            echo esc_html($estate_featured);
        }
    }
endif;

add_filter('manage_edit-estate_property_sortable_columns', 'wpestate_sort_me');
if (!function_exists('wpestate_sort_me')):
    /**
     * Makes certain columns sortable in the admin interface
     *
     * @param array $columns Current sortable columns
     * @return array Modified array of sortable columns
     */
    function wpestate_sort_me($columns) {
        $columns['estate_autor'] = 'estate_autor';
        $columns['estate_featured'] = 'estate_featured';
        $columns['estate_price'] = 'estate_price';
        return $columns;
    }
endif;

add_filter('request', 'bs_event_date_column_orderby_core');
/**
 * Handles the sorting functionality for custom columns
 *
 * @param array $vars The query variables
 * @return array Modified query variables
 */
function bs_event_date_column_orderby_core($vars) {
    if (isset($vars['orderby']) && 'estate_featured' == $vars['orderby']) {
        $vars = array_merge($vars, array(
            'meta_key' => 'prop_featured',
            'orderby' => 'meta_value_num'
                ));
    }
    if (isset($vars['orderby']) && 'estate_price' == $vars['orderby']) {
        $vars = array_merge($vars, array(
            'meta_key' => 'property_price',
            'orderby' => 'meta_value_num'
                ));
    }
    if (isset($vars['orderby']) && 'estate_autor' == $vars['orderby']) {
        $vars = array_merge($vars, array(
            'orderby' => 'author'
                ));
    }
    return $vars;
}

add_filter('manage_edit-property_city_columns', 'ST4_city_columns_head');
add_filter('manage_property_city_custom_column', 'ST4_city_columns_content_taxonomy', 10, 3);

if (!function_exists('ST4_city_columns_head')):
    /**
     * Defines columns for the property city taxonomy admin interface
     *
     * @param array $new_columns The default columns
     * @return array Modified columns array
     */
    function ST4_city_columns_head($new_columns) {
        $new_columns = array(
            'cb' => '<input type="checkbox" />',
            'name' => esc_html__('Name', 'wpresidence-core'),
            'county' => esc_html__('County / State', 'wpresidence-core'),
            'id' => esc_html__('ID', 'wpresidence-core'),
            'header_icon' => '',
            'slug' => esc_html__('Slug', 'wpresidence-core'),
            'posts' => esc_html__('Posts', 'wpresidence-core')
        );
        return $new_columns;
    }
endif;

if (!function_exists('ST4_city_columns_content_taxonomy')):
    /**
     * Populates content for the custom city taxonomy columns
     *
     * @param string $out The output string
     * @param string $column_name The name of the column
     * @param int $term_id The term ID
     * @return void
     */
    function ST4_city_columns_content_taxonomy($out, $column_name, $term_id) {
        if ($column_name == 'county') {
            $term_meta = get_option("taxonomy_$term_id");
            if (isset($term_meta['stateparent'])) {
                print stripslashes($term_meta['stateparent']);
            }
        }
        if ($column_name == 'id') {
            echo $term_id;
        }
    }
endif;



add_filter('manage_edit-property_area_columns', 'ST4_columns_head');
add_filter('manage_property_area_custom_column', 'ST4_columns_content_taxonomy', 10, 3);

if (!function_exists('ST4_columns_head')):
    /**
     * Defines columns for the property area taxonomy admin interface
     * Sets up the columns shown in the property area listing table
     *
     * @param array $new_columns The default WordPress columns
     * @return array Modified array of columns
     */
    function ST4_columns_head($new_columns) {
        $new_columns = array(
            'cb' => '<input type="checkbox" />',
            'name' => esc_html__('Name', 'wpresidence-core'),
            'city' => esc_html__('City', 'wpresidence-core'),
            'id' => esc_html__('ID', 'wpresidence-core'),
            'header_icon' => '',
            'slug' => esc_html__('Slug', 'wpresidence-core'),
            'posts' => esc_html__('Posts', 'wpresidence-core')
        );

        return $new_columns;
    }
endif;

if (!function_exists('ST4_columns_content_taxonomy')):
    /**
     * Populates content for the property area taxonomy columns
     * Displays the parent city and term ID for each property area
     *
     * @param string $out The output string
     * @param string $column_name The name of the column
     * @param int $term_id The term ID
     * @return void
     */
    function ST4_columns_content_taxonomy($out, $column_name, $term_id) {
        if ($column_name == 'city') {
            $term_meta = get_option("taxonomy_$term_id");
            if (isset($term_meta['cityparent'])) {
                print stripslashes($term_meta['cityparent']);
            }
        }
        if ($column_name == 'id') {
            echo $term_id;
        }
    }
endif;


/**
 * Add ID Column to WordPress Admin Tables
 *
 * This set of filters and actions adds an ID column to various admin tables in WordPress,
 * including posts, pages, media, categories, and custom WP Estate taxonomies.
 * Displaying IDs in admin tables makes it easier for administrators to reference specific items
 * when working with templates, shortcodes, or custom code.
 *
 * @package WP Estate
 * @subpackage Admin UI
 */

// Add ID column to standard WordPress post types
add_filter('manage_posts_columns', 'wpestate_add_id_column', 5);
add_action('manage_posts_custom_column', 'wpestate_id_column_content', 5, 2);
add_filter('manage_pages_columns', 'wpestate_add_id_column', 5);
add_action('manage_pages_custom_column', 'wpestate_id_column_content', 5, 2);
add_filter('manage_media_columns', 'wpestate_add_id_column', 5);
add_action('manage_media_custom_column', 'wpestate_id_column_content', 5, 2);

// Add ID column to standard WordPress categories
add_action('manage_edit-category_columns', 'wpestate_add_id_column', 5);
add_filter('manage_category_custom_column', 'wpestate_categoriesColumnsRow', 10, 3);

// Add ID column to agent-related taxonomies
add_action('manage_edit-property_category_agent_columns', 'wpestate_add_id_column', 5);
add_filter('manage_property_category_agent_custom_column', 'wpestate_categoriesColumnsRow', 10, 3);
add_action('manage_edit-property_action_category_agent_columns', 'wpestate_add_id_column', 5);
add_filter('manage_property_action_category_agent_custom_column', 'wpestate_categoriesColumnsRow', 10, 3);
add_action('manage_edit-property_city_agent_columns', 'wpestate_add_id_column', 5);
add_filter('manage_property_city_agent_custom_column', 'wpestate_categoriesColumnsRow', 10, 3);
add_action('manage_edit-property_area_agent_columns', 'wpestate_add_id_column', 5);
add_filter('manage_property_area_agent_custom_column', 'wpestate_categoriesColumnsRow', 10, 3);
add_action('manage_edit-property_county_state_agent_columns', 'wpestate_add_id_column', 5);
add_filter('manage_property_county_state_agent_custom_column', 'wpestate_categoriesColumnsRow', 10, 3);

// Add ID column to property-related taxonomies
add_action('manage_edit-property_category_columns', 'wpestate_add_id_column', 5);
add_filter('manage_property_category_custom_column', 'wpestate_categoriesColumnsRow', 10, 3);
add_action('manage_edit-property_action_category_columns', 'wpestate_add_id_column', 5);
add_filter('manage_property_action_category_custom_column', 'wpestate_categoriesColumnsRow', 10, 3);
add_action('manage_edit-property_city_columns', 'wpestate_add_id_column', 5);
add_filter('manage_property_city_custom_column', 'wpestate_categoriesColumnsRow', 10, 3);
add_action('manage_edit-property_county_state_columns', 'wpestate_add_id_column', 5);
add_filter('manage_property_county_state_custom_column', 'wpestate_categoriesColumnsRow', 10, 3);

/**
 * Add ID Column to Admin Tables
 * 
 * This function adds a new column called 'ID' to WordPress admin tables.
 * The column is registered with the internal name 'revealid_id'.
 *
 * @param array $columns Existing columns array
 * @return array Modified columns array with ID column added
 */
function wpestate_add_id_column($columns) {
   $columns['revealid_id'] = 'ID';
   return $columns;
}

/**
 * Display ID in Column for Posts, Pages, and Media
 * 
 * This function outputs the ID value in the custom column for post types.
 * It's used by the standard WordPress post types (posts, pages, media).
 *
 * @param string $column The column name
 * @param int $id The ID of the current item
 * @return void
 */
function wpestate_id_column_content($column, $id) {
    if('revealid_id' == $column) {
        print intval($id);
    }
}

/**
 * Display ID in Column for Categories and Taxonomies
 * 
 * This function returns the ID value for the custom column in taxonomy tables.
 * It's used by categories and custom taxonomies to display their term IDs.
 *
 * @param string $argument Default output for the column
 * @param string $columnName The name of the column
 * @param int $categoryID The ID of the current taxonomy term
 * @return int|string The category ID if in the ID column, otherwise original argument
 */
function wpestate_categoriesColumnsRow($argument, $columnName, $categoryID) {
    if($columnName == 'revealid_id') {
        return $categoryID;
    }
}